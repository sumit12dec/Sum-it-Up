  /************************************************************************************
  This is your Page Code. The appAPI.ready() code block will be executed on every page load.
  For more information please visit our docs site: http://docs.crossrider.com
*************************************************************************************/

appAPI.ready(function($) {

    // Place your code here (you can also define new functions above this scope)
    // The $ object is the extension's jQuery

    //alert("sdfghkjl");
    appAPI.message.addListener(function(msg) {
       if (msg.type === 'linkUrl'){
       var base_url = 'http://sum-it-up.herokuapp.com/API?url=';
       var linkUrl = msg.data;
       var url = base_url + linkUrl;
       appAPI.request.get({
        url: url,
        onSuccess: function(response, additionalInfo) {
            // Display the response
                //alert(response);
                //alert(response);
                showNotification(response);
                }    
       });
     }       
});


 function showNotification(data) {
    // You can replace the notifier with your own custom code
    appAPI.notifier.show({
      'name':'my-notification-name',
      'title':'Sum-it-Up',
      'body':'<span style="font-weight:bold;color:red;">'+ data +'</span>',
      'link':'http://techpython.com/demo.html',
      'theme':'default',
      'position':'top-right',
      'close':true,
      'sticky':true,
      'width':'400px',
      'closeWhenClicked':true
    });
  }

});
