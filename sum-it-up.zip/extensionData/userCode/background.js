/************************************************************************************
  This is your background code.
  For more information please visit our wiki site:
  http://docs.crossrider.com/#!/guide/background_scope
*************************************************************************************/

/*
 * Description:
 *   This extension demonstrates how to add one or more commands to the context menus
 *   that appear when you right-click on elements within a page.
 *
 * Usage:
 *   Runs in the browser's background
 *
 * Reference:
 *   http://docs.crossrider.com/#!/api/appAPI.contextMenu
 */

// Place your code here (ideal for handling browser button, global timers, etc.)

// Adds a new command to all content menus that displays the values of the data
// object that passed back to the callback functio

appAPI.contextMenu.add("key1", "Sum-it-Up", function (data) {
    var linkUrl= data.linkUrl;
    appAPI.message.toActiveTab({type:'linkUrl', data: linkUrl});
        //alert(sAlertText)
}, ["link"]);






