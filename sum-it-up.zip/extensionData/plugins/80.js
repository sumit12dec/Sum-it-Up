
appAPI.browserAction.closePopup=function(){window.close();};
